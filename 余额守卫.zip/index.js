/**
 * dsh-balance-guard — Host half.
 *
 * 实时读取 DeepSeek 账号余额（走 DSH 自己的 `deepseekAccount` 服务，不自己拼 HTTP），
 * 在余额掉到警戒线以下时用 `agent.cancel()` 中断所有正在跑的任务，
 * 并把当前余额 / 警戒线 / 开关通过两条本机 HTTP 接口交给浏览器半侧显示和修改。
 */

const STATE_PATH = '/dsh-balance-guard/state'
const SETTINGS_PATH = '/dsh-balance-guard/settings'
const JSON_HEADERS = {
  'Content-Type': 'application/json; charset=utf-8',
  'Cache-Control': 'no-store',
}

const DEFAULTS = {
  /** 余额警戒线（元 / 美元）。0 = 关闭自动停止。 */
  threshold: 5,
  /** 余额低于警戒线时是否中断任务。 */
  autoStop: true,
  /** Host 轮询余额的间隔（秒）。 */
  pollSeconds: 20,
  /** 两次真正打平台接口之间的最小间隔（毫秒），前端频繁刷新时用它兜底。 */
  minRefreshMs: 10_000,
}

function clampNumber(value, min, max, fallback) {
  const n = Number(value)
  if (!Number.isFinite(n)) return fallback
  return Math.min(max, Math.max(min, n))
}

function normalizeConfig(raw) {
  const source = raw && typeof raw === 'object' ? raw : {}
  return {
    threshold: clampNumber(source.threshold, 0, 10_000_000, DEFAULTS.threshold),
    autoStop: source.autoStop === undefined ? DEFAULTS.autoStop : Boolean(source.autoStop),
    pollSeconds: clampNumber(source.pollSeconds, 5, 3600, DEFAULTS.pollSeconds),
    minRefreshMs: clampNumber(source.minRefreshMs, 0, 10 * 60_000, DEFAULTS.minRefreshMs),
  }
}

function readBody(req, maxBytes = 8192) {
  return new Promise((resolve, reject) => {
    const chunks = []
    let size = 0
    req.on('data', (chunk) => {
      size += chunk.length
      if (size > maxBytes) {
        reject(new Error('body too large'))
        req.destroy()
        return
      }
      chunks.push(chunk)
    })
    req.on('end', () => resolve(Buffer.concat(chunks).toString('utf8')))
    req.on('error', reject)
  })
}

/**
 * @param ctx - Host plugin context.
 * @param config - this row's config, as written by the bundle patch and the config editor.
 */
export function apply(ctx, config) {
  const settings = normalizeConfig(config)

  const state = {
    /** 最近一次查询是否成功。 */
    ok: false,
    /** 是否拿到了账号（未登录时为 false）。 */
    signedIn: false,
    /** 充值 + 赠金合计。 */
    total: null,
    recharge: null,
    bonus: null,
    currency: 'CNY',
    /** 失败原因，只用于文案。 */
    error: '',
    /** 最近一次成功查询的时间戳（毫秒）。 */
    updatedAt: 0,
    /** 是否已经触发过停止。 */
    tripped: false,
    trippedAt: 0,
    /** 最近一次触发时中断了多少个正在跑的任务。 */
    stoppedAgents: 0,
  }

  let lastFetchAt = 0
  let inflight = null

  /** 通过 DSH 账号服务读取余额；返回 null 表示读不到（未登录 / 失败）。 */
  async function fetchAccountBalance() {
    let account = null
    try {
      account = typeof ctx.get === 'function' ? ctx.get('deepseekAccount') : null
    } catch {
      account = null
    }
    if (!account || typeof account.getBalance !== 'function') {
      state.error = '当前 DSH 没有账号服务'
      return null
    }

    let result
    try {
      result = await account.getBalance({
        version: String(process.env.DSH_CLIENT_VERSION || 'unknown') || 'unknown',
        locale: String(process.env.DSH_LOCALE || '') || 'zh_CN',
        // Date.getTimezoneOffset 是以西为正的分钟数；平台要的是以东为正的秒。
        timezoneOffsetSeconds: -new Date().getTimezoneOffset() * 60,
      })
    } catch (err) {
      state.error = '账号余额接口调用失败: ' + String((err && err.message) || err).slice(0, 160)
      return null
    }

    if (!result) {
      state.signedIn = false
      state.error = '未登录 DeepSeek 账号（没有账号凭据）'
      return null
    }
    if (result.status !== 'ready') {
      state.signedIn = true
      state.error = '账号余额接口未就绪（' + String(result.status || 'unknown') + '）'
      return null
    }

    state.signedIn = true
    const num = (value) => {
      const n = Number(value)
      return Number.isFinite(n) ? n : null
    }
    const usable = (list) => (Array.isArray(list) ? list : []).filter((w) => w && num(w.balance) !== null)
    const normal = usable(result.value)
    const bonus = usable(result.bonusWallets)
    const all = normal.concat(bonus)
    if (all.length === 0) {
      state.error = '账号没有可用的余额钱包'
      return null
    }

    const currencyOf = (wallet) => String((wallet && wallet.currency) || 'CNY').toUpperCase()
    const nonZero = all.filter((wallet) => Number(wallet.balance) > 0)
    const picked = nonZero.find((w) => currencyOf(w) === 'CNY')
      || nonZero[0]
      || all.find((w) => currencyOf(w) === 'CNY')
      || all[0]
    const currency = currencyOf(picked)
    const sumOf = (list) => list
      .filter((wallet) => currencyOf(wallet) === currency)
      .reduce((sum, wallet) => sum + Number(wallet.balance), 0)
    const recharge = sumOf(normal)
    const bonusSum = sumOf(bonus)

    state.error = ''
    return {
      total: Number((recharge + bonusSum).toFixed(6)),
      recharge: Number(recharge.toFixed(6)),
      bonus: Number(bonusSum.toFixed(6)),
      currency,
    }
  }

  /** 余额低于警戒线时，把正在跑的任务全部中断。 */
  function enforceGuard() {
    if (!settings.autoStop) {
      state.tripped = false
      state.stoppedAgents = 0
      return
    }
    if (!(settings.threshold > 0) || state.total === null) return

    if (state.total > settings.threshold) {
      state.tripped = false
      state.stoppedAgents = 0
      return
    }

    let agents = null
    try {
      agents = typeof ctx.get === 'function' ? ctx.get('agents') : null
    } catch {
      agents = null
    }
    let stopped = 0
    if (agents && typeof agents.list === 'function') {
      for (const agent of agents.list()) {
        try {
          if (agent && agent.status === 'running') {
            agent.cancel({ kind: 'hook', reason: 'balance-guard: 余额低于警戒线，任务已中断' })
            stopped += 1
          }
        } catch {
          // 单个 agent 取消失败不影响其它 agent。
        }
      }
    } else {
      state.error = state.error || '当前 DSH 没有 agent 注册表，无法中断任务'
    }

    if (!state.tripped) {
      state.tripped = true
      state.trippedAt = Date.now()
    }
    if (stopped > 0) state.stoppedAgents = stopped
    if (stopped > 0) {
      console.warn('[balance-guard] 余额 ' + state.total + ' 低于警戒线 ' + settings.threshold + '，已中断 ' + stopped + ' 个任务')
    }
  }

  /** 查询余额（带最小间隔），成功则立刻跑一次守卫判定。 */
  function refresh(force) {
    if (inflight) return inflight
    const now = Date.now()
    if (!force && now - lastFetchAt < settings.minRefreshMs) return Promise.resolve(state)
    if (force && now - lastFetchAt < Math.min(settings.minRefreshMs, 2_000)) return Promise.resolve(state)

    lastFetchAt = now
    inflight = (async () => {
      try {
        const value = await fetchAccountBalance()
        if (value) {
          state.ok = true
          state.total = value.total
          state.recharge = value.recharge
          state.bonus = value.bonus
          state.currency = value.currency
          state.updatedAt = Date.now()
        } else {
          state.ok = false
        }
        enforceGuard()
      } catch (err) {
        state.ok = false
        state.error = String((err && err.message) || err).slice(0, 160)
      } finally {
        inflight = null
      }
      return state
    })()
    return inflight
  }

  /** 给浏览器半侧的完整快照。 */
  function snapshot() {
    return {
      ok: state.ok,
      signedIn: state.signedIn,
      total: state.total,
      recharge: state.recharge,
      bonus: state.bonus,
      currency: state.currency,
      error: state.error,
      updatedAt: state.updatedAt,
      tripped: state.tripped,
      trippedAt: state.trippedAt,
      stoppedAgents: state.stoppedAgents,
      threshold: settings.threshold,
      autoStop: settings.autoStop,
      pollSeconds: settings.pollSeconds,
    }
  }

  /** 把改动写回本插件行的 config（走 configEditor，不手改 profile 的 patch 文件）。 */
  async function persist(patch) {
    let entry
    try {
      entry = ctx.fiber && ctx.fiber.entry
    } catch {
      entry = undefined
    }
    const editor = typeof ctx.get === 'function' ? ctx.get('configEditor') : null
    if (!entry || !editor || typeof editor.edit !== 'function') return false
    await editor.edit(entry, (current) => ({ ...current, ...patch }))
    return true
  }

  // 定时轮询：Task 一结束就没人管余额了，所以插件自己带着计时器跑。
  ctx.effect(() => {
    const timer = setInterval(() => { void refresh(false) }, settings.pollSeconds * 1000)
    const kickoff = setTimeout(() => { void refresh(true) }, 1_200)
    return () => {
      clearInterval(timer)
      clearTimeout(kickoff)
    }
  }, 'balance-guard: poll')

  // HTTP 接口：只在有 webServer 的宿主上注册，没有就只剩后台守卫。
  ctx.inject(['webServer'], (scoped) => {
    scoped.effect(() => {
      const disposeState = scoped.webServer.register({
        kind: 'exact',
        path: STATE_PATH,
        handler: async (req, res) => {
          try {
            const refreshRequested = new URL(req.url || '/', 'http://localhost').searchParams.get('refresh') === '1'
            if (refreshRequested) await refresh(false)
            res.writeHead(200, JSON_HEADERS)
            res.end(JSON.stringify(snapshot()))
          } catch (err) {
            res.writeHead(200, JSON_HEADERS)
            res.end(JSON.stringify({ ...snapshot(), ok: false, error: String((err && err.message) || err).slice(0, 160) }))
          }
        },
      })

      const disposeSettings = scoped.webServer.register({
        kind: 'exact',
        path: SETTINGS_PATH,
        handler: async (req, res) => {
          if (req.method !== 'POST') {
            res.writeHead(200, JSON_HEADERS)
            res.end(JSON.stringify(snapshot()))
            return
          }
          const patch = {}
          try {
            const raw = await readBody(req)
            const body = raw ? JSON.parse(raw) : {}
            if (body && body.threshold !== undefined) {
              const next = clampNumber(body.threshold, 0, 10_000_000, settings.threshold)
              settings.threshold = next
              patch.threshold = next
            }
            if (body && body.autoStop !== undefined) {
              settings.autoStop = Boolean(body.autoStop)
              patch.autoStop = settings.autoStop
            }
          } catch (err) {
            res.writeHead(400, JSON_HEADERS)
            res.end(JSON.stringify({ ok: false, error: '请求体无效: ' + String((err && err.message) || err).slice(0, 120) }))
            return
          }

          // 先按内存里的新值重判一次，界面立刻能看到效果；持久化异步做，失败只记日志。
          enforceGuard()
          res.writeHead(200, JSON_HEADERS)
          res.end(JSON.stringify({ ...snapshot(), saved: Object.keys(patch).length > 0 }))

          if (Object.keys(patch).length > 0) {
            void persist(patch).then((saved) => {
              if (!saved) console.warn('[balance-guard] 配置未能写入 profile（缺少 configEditor）')
            }).catch((err) => {
              console.warn('[balance-guard] 配置写入失败: ' + String((err && err.message) || err).slice(0, 160))
            })
          }
        },
      })

      return () => {
        try { disposeState() } catch { /* 已经卸载 */ }
        try { disposeSettings() } catch { /* 已经卸载 */ }
      }
    }, 'balance-guard: routes')
  })
}
