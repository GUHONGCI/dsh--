(() => {
  try {
    /* dsh-balance-guard client half —— 输入框下方的余额徽标 + 警戒线编辑 */
    window.__ModuleLoader__.load({
      id: 'dsh-balance-guard',
      factory: (require) => {
        var module = { exports: {} };
        var exports = module.exports;
        Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });

        var React = require('react');

        var NS = 'balanceGuard';
        var STATE_URL = '/dsh-balance-guard/state';
        var SETTINGS_URL = '/dsh-balance-guard/settings';
        var POLL_MS = 5000;

        var DICT = {
          zh: {
            balance: '余额',
            'balance.title': 'DeepSeek 账号余额，每 5 秒刷新一次',
            threshold: '警戒线',
            unit: '元',
            save: '保存',
            autoStop: '低于警戒线时停止任务',
            'status.normal': '运行中',
            'status.tripped': '已触发：任务已被中断',
            'status.signedOut': '未登录 DeepSeek 账号',
            'status.failed': '余额读取失败',
            'status.loading': '读取中…',
            saved: '已保存',
            failed: '保存失败',
            invalid: '警戒线要填不小于 0 的数字',
            stopped: '已中断'
          },
          en: {
            balance: 'Balance',
            'balance.title': 'DeepSeek account balance, refreshed every 5 seconds',
            threshold: 'Threshold',
            unit: 'CNY',
            save: 'Save',
            autoStop: 'Stop tasks below the threshold',
            'status.normal': 'Watching',
            'status.tripped': 'Tripped: tasks were stopped',
            'status.signedOut': 'Not signed in to a DeepSeek account',
            'status.failed': 'Balance read failed',
            'status.loading': 'Reading…',
            saved: 'Saved',
            failed: 'Save failed',
            invalid: 'Enter a threshold of 0 or more',
            stopped: 'stopped'
          }
        };

        function fallbackT(key) {
          var table = DICT.zh;
          return Object.prototype.hasOwnProperty.call(table, key) ? table[key] : key;
        }

        function money(total, currency) {
          if (total === null || total === undefined || !isFinite(Number(total))) return '--';
          var sign = String(currency || 'CNY').toUpperCase() === 'USD' ? '$' : '¥';
          var value = Math.round(Number(total) * 100) / 100;
          return sign + value.toFixed(2);
        }

        var WRAP = {
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'flex-start',
          gap: '4px',
          minWidth: '0'
        };

        function pillStyle(danger, warn, open) {
          var color = danger
            ? 'var(--dsw-alias-state-error-primary, #e5484d)'
            : warn
              ? 'var(--dsw-alias-state-warn-primary, #d97706)'
              : 'var(--dsw-alias-label-tertiary, #8b8b8b)';
          return {
            display: 'inline-flex',
            alignItems: 'center',
            gap: '6px',
            padding: '1px 8px',
            border: '1px solid transparent',
            borderRadius: 'var(--dsw-radius-sm, 6px)',
            background: open ? 'var(--dsw-alias-interactive-bg-hover, rgba(127,127,127,.12))' : 'transparent',
            color: color,
            font: 'inherit',
            fontSize: 'calc(var(--dsh-content-font-size-secondary, 13px) - 1px)',
            fontVariantNumeric: 'tabular-nums',
            lineHeight: '20px',
            cursor: 'pointer',
            whiteSpace: 'nowrap'
          };
        }

        function dotStyle(danger, warn) {
          return {
            width: '6px',
            height: '6px',
            borderRadius: '50%',
            flex: 'none',
            background: danger
              ? 'var(--dsw-alias-state-error-primary, #e5484d)'
              : warn
                ? 'var(--dsw-alias-state-warn-primary, #d97706)'
                : 'var(--dsw-alias-state-success-primary, #10b981)'
          };
        }

        var PANEL = {
          display: 'flex',
          flexDirection: 'column',
          gap: '6px',
          padding: '8px 10px',
          border: '1px solid var(--dsw-alias-border-l1, rgba(127,127,127,.28))',
          borderRadius: 'var(--dsw-radius-sm, 6px)',
          background: 'var(--dsw-alias-bg-overlay, rgba(24,24,24,.96))',
          color: 'var(--dsw-alias-label-secondary, #b4b4b4)',
          fontSize: '12px',
          lineHeight: '18px',
          fontVariantNumeric: 'tabular-nums'
        };

        var ROW = {
          display: 'flex',
          alignItems: 'center',
          gap: '6px',
          flexWrap: 'wrap'
        };

        function inputStyle() {
          return {
            width: '72px',
            padding: '1px 6px',
            border: '1px solid var(--dsw-alias-border-l2, rgba(127,127,127,.4))',
            borderRadius: 'var(--dsw-radius-sm, 6px)',
            background: 'var(--dsw-alias-bg-layer-1, rgba(0,0,0,.25))',
            color: 'var(--dsw-alias-label-primary, #ededed)',
            font: 'inherit',
            fontSize: '12px',
            lineHeight: '18px'
          };
        }

        function buttonStyle() {
          return {
            padding: '1px 8px',
            border: '1px solid var(--dsw-alias-border-l2, rgba(127,127,127,.4))',
            borderRadius: 'var(--dsw-radius-sm, 6px)',
            background: 'var(--dsw-alias-bg-layer-2, rgba(127,127,127,.14))',
            color: 'var(--dsw-alias-label-primary, #ededed)',
            font: 'inherit',
            fontSize: '12px',
            lineHeight: '18px',
            cursor: 'pointer'
          };
        }

        function BalancePill(props) {
          var tr = props && typeof props.t === 'function' ? props.t : fallbackT;

          var dataPair = React.useState(null);
          var data = dataPair[0];
          var setData = dataPair[1];

          var openPair = React.useState(false);
          var open = openPair[0];
          var setOpen = openPair[1];

          var draftPair = React.useState('');
          var draft = draftPair[0];
          var setDraft = draftPair[1];

          var busyPair = React.useState(false);
          var busy = busyPair[0];
          var setBusy = busyPair[1];

          var notePair = React.useState('');
          var note = notePair[0];
          var setNote = notePair[1];

          var tickRef = React.useRef(0);

          React.useEffect(function () {
            var alive = true;
            var timer = null;

            function load(force) {
              fetch(STATE_URL + (force ? '?refresh=1' : ''), { cache: 'no-store' })
                .then(function (response) { return response.json(); })
                .then(function (json) {
                  if (alive && json && typeof json === 'object') setData(json);
                })
                .catch(function () {
                  /* 宿主还没起来或接口暂时不可用：保留上一份数据，下一轮再说。 */
                });
            }

            load(true);
            timer = setInterval(function () {
              tickRef.current += 1;
              load(tickRef.current % 3 === 0);
            }, POLL_MS);

            return function () {
              alive = false;
              if (timer !== null) clearInterval(timer);
            };
          }, []);

          function toggle() {
            var next = !open;
            setOpen(next);
            setNote('');
            if (next && data) setDraft(String(data.threshold));
          }

          function submit(patch, okKey) {
            setBusy(true);
            setNote('');
            fetch(SETTINGS_URL, {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify(patch)
            })
              .then(function (response) { return response.json(); })
              .then(function (json) {
                if (json && typeof json === 'object' && !json.error) {
                  setData(json);
                  setNote(tr(okKey || 'saved'));
                } else {
                  setNote(tr('failed'));
                }
              })
              .catch(function () { setNote(tr('failed')); })
              .then(function () { setBusy(false); });
          }

          function saveThreshold() {
            var next = Number(draft);
            if (!isFinite(next) || next < 0) {
              setNote(tr('invalid'));
              return;
            }
            submit({ threshold: next }, 'saved');
          }

          function toggleAutoStop() {
            submit({ autoStop: !(data && data.autoStop) }, 'saved');
          }

          var total = data ? data.total : null;
          var currency = (data && data.currency) || 'CNY';
          var threshold = data ? Number(data.threshold) : 0;
          var autoStop = data ? !!data.autoStop : true;
          var tripped = data ? !!data.tripped : false;
          var danger = tripped || (total !== null && threshold > 0 && Number(total) <= threshold);
          var warn = !danger && total !== null && threshold > 0 && Number(total) <= threshold * 2;

          var status;
          if (!data) status = tr('status.loading');
          else if (data.tripped) {
            status = tr('status.tripped') + (data.stoppedAgents > 0 ? '（' + tr('stopped') + ' ' + data.stoppedAgents + '）' : '');
          } else if (data.signedIn === false && !data.ok) status = tr('status.signedOut');
          else if (!data.ok && data.error) status = tr('status.failed') + '：' + data.error;
          else status = tr('status.normal');

          var children = [
            React.createElement(
              'button',
              {
                key: 'pill',
                type: 'button',
                style: pillStyle(danger, warn, open),
                onClick: toggle,
                title: tr('balance.title'),
                'aria-expanded': open,
                'data-balance-guard': 'pill'
              },
              React.createElement('span', { style: dotStyle(danger, warn), 'aria-hidden': true }),
              React.createElement('span', null, tr('balance') + ' ' + money(total, currency))
            )
          ];

          if (open) {
            children.push(
              React.createElement(
                'div',
                { key: 'panel', style: PANEL, role: 'group', 'aria-label': tr('threshold'), 'data-balance-guard': 'panel' },
                React.createElement(
                  'div',
                  { style: ROW },
                  React.createElement('span', null, tr('threshold')),
                  React.createElement('input', {
                    type: 'number',
                    min: '0',
                    step: '0.5',
                    style: inputStyle(),
                    value: draft,
                    disabled: busy,
                    'aria-label': tr('threshold'),
                    onChange: function (event) { setDraft(event.target.value); }
                  }),
                  React.createElement('span', null, tr('unit')),
                  React.createElement(
                    'button',
                    { type: 'button', style: buttonStyle(), disabled: busy, onClick: saveThreshold },
                    tr('save')
                  )
                ),
                React.createElement(
                  'label',
                  { style: { display: 'flex', alignItems: 'center', gap: '6px', cursor: 'pointer' } },
                  React.createElement('input', {
                    type: 'checkbox',
                    checked: autoStop,
                    disabled: busy,
                    onChange: toggleAutoStop
                  }),
                  React.createElement('span', null, tr('autoStop'))
                ),
                React.createElement('div', { style: { color: danger ? 'var(--dsw-alias-state-error-primary, #e5484d)' : 'inherit' } }, status),
                note ? React.createElement('div', null, note) : null
              )
            );
          }

          return React.createElement('div', { style: WRAP, 'data-plugin': 'dsh-balance-guard' }, children);
        }

        function apply(ctx) {
          ctx.effect(function () {
            return ctx.locale.register(NS, DICT);
          }, 'balance-guard: dictionaries');
          ctx.slots.inject('conversation.composer.dock', function () {
            return ctx.slots.register({
              name: 'conversation.composer.dock',
              id: 'balance-guard',
              order: 2,
              locale: NS
            }, BalancePill);
          });
        }

        exports.name = 'dsh-balance-guard';
        exports.inject = ['slots', 'locale'];
        exports.apply = apply;
        return module.exports;
      }
    });
  } catch (err) {
    console.warn('[dsh-balance-guard] client runtime error:', err);
  }
})();
