# 更新日志

## 1.0.0 — 2026-11-17

首个版本。

### 新增

- Host 半侧定时轮询 DeepSeek 账号余额，复用 DSH 的 `deepseekAccount.getBalance`，充值钱包与赠金钱包一起算。
- 输入框（composer）dock 行余额徽标：绿＝正常、橙＝接近警戒线、红＝已触发。
- 点开徽标可编辑警戒线、开关「低于警戒线时停止任务」，改动经 `configEditor` 写回插件行 config。
- 余额 ≤ 警戒线时用 `agent.cancel({ kind: 'hook' })` 中断所有 `running` 任务，取消原因可在会话日志中识别。
- 两条本机接口：`GET /dsh-balance-guard/state`、`POST /dsh-balance-guard/settings`。
- 中英文界面字典（`locale/zh.json`、`locale/en.json`）。
- 配置项 `threshold` / `autoStop` / `pollSeconds` / `minRefreshMs`，均带范围钳制。
